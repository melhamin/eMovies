class PersonModel {
  final String name;
  final DateTime birthday;
  final String placeOfBirth;
  final String biography;
  final movies;  

  PersonModel({
    this.name,
    this.birthday,
    this.placeOfBirth,
    this.biography,
    this.movies,
  });
}